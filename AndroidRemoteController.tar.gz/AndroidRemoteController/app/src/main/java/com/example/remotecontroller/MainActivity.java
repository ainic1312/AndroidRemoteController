package com.example.remotecontroller;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    private TextView statusText;
    private Button connectButton;
    private Button upButton;
    private Button downButton;
    private Button leftButton;
    private Button rightButton;
    private Button okButton;
    
    private boolean isConnected = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // 初始化UI组件
        initViews();
        setupListeners();
        
        // 初始状态
        updateConnectionStatus();
    }
    
    private void initViews() {
        statusText = findViewById(R.id.status_text);
        connectButton = findViewById(R.id.connect_button);
        upButton = findViewById(R.id.up_button);
        downButton = findViewById(R.id.down_button);
        leftButton = findViewById(R.id.left_button);
        rightButton = findViewById(R.id.right_button);
        okButton = findViewById(R.id.ok_button);
    }
    
    private void setupListeners() {
        connectButton.setOnClickListener(v -> toggleConnection());
        upButton.setOnClickListener(v -> sendCommand("UP"));
        downButton.setOnClickListener(v -> sendCommand("DOWN"));
        leftButton.setOnClickListener(v -> sendCommand("LEFT"));
        rightButton.setOnClickListener(v -> sendCommand("RIGHT"));
        okButton.setOnClickListener(v -> sendCommand("OK"));
    }
    
    private void toggleConnection() {
        if (isConnected) {
            disconnect();
        } else {
            connect();
        }
    }
    
    private void connect() {
        // TODO: 实现设备连接逻辑
        isConnected = true;
        updateConnectionStatus();
        Toast.makeText(this, "设备已连接", Toast.LENGTH_SHORT).show();
    }
    
    private void disconnect() {
        // TODO: 实现设备断开逻辑
        isConnected = false;
        updateConnectionStatus();
        Toast.makeText(this, "设备已断开", Toast.LENGTH_SHORT).show();
    }
    
    private void updateConnectionStatus() {
        if (isConnected) {
            statusText.setText("状态: 已连接");
            connectButton.setText("断开连接");
            enableControlButtons(true);
        } else {
            statusText.setText("状态: 未连接");
            connectButton.setText("连接设备");
            enableControlButtons(false);
        }
    }
    
    private void enableControlButtons(boolean enabled) {
        upButton.setEnabled(enabled);
        downButton.setEnabled(enabled);
        leftButton.setEnabled(enabled);
        rightButton.setEnabled(enabled);
        okButton.setEnabled(enabled);
    }
    
    private void sendCommand(String command) {
        if (!isConnected) {
            Toast.makeText(this, "请先连接设备", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // TODO: 实现命令发送逻辑
        Toast.makeText(this, "发送命令: " + command, Toast.LENGTH_SHORT).show();
        
        // 模拟命令发送
        // RemoteControllerService.sendCommand(command);
    }
}