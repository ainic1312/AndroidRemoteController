# 编译说明

## 编译步骤

1. **安装 Android Studio**
   - 下载并安装最新版 Android Studio
   - 确保安装 Android SDK 和必要的构建工具

2. **导入项目**
   - 打开 Android Studio
   - 选择 "Open an existing project"
   - 导航到 `AndroidRemoteController` 文件夹

3. **同步 Gradle**
   - 项目导入后会自动同步 Gradle
   - 如果遇到问题，点击 "Sync Project with Gradle Files"

4. **编译 APK**
   - 选择 Build → Build Bundle(s) / APK(s) → Build APK(s)
   - 或者使用 Gradle 命令：`./gradlew assembleDebug`

5. **获取 APK 文件**
   - 编译完成后，APK 文件位于：
     `app/build/outputs/apk/debug/app-debug.apk`

## 依赖要求
- Android SDK 34
- Java 8+
- Gradle 8.0+

## 注意事项
- 确保设备已启用开发者选项和USB调试
- 可能需要配置签名密钥用于正式发布
- 首次编译可能需要下载依赖，请保持网络连接