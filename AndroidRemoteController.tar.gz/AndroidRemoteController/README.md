# 安卓遥控器项目

一个基础的安卓遥控器应用，支持设备控制和通信功能。

## 功能特性
- 设备连接管理
- 远程控制界面
- 通信协议支持
- 状态监控

## 技术栈
- Android (Java/Kotlin)
- 蓝牙/WiFi通信
- 自定义UI控件

## 项目结构
```
AndroidRemoteController/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/remotecontroller/
│   │   │   ├── res/
│   │   │   └── AndroidManifest.xml
│   │   └── test/
│   ├── build.gradle
│   └── proguard-rules.pro
├── gradle/
├── build.gradle
├── settings.gradle
└── gradle.properties
```